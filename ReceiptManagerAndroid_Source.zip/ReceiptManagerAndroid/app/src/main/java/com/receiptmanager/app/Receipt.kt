package com.receiptmanager.app

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "receipts")
data class Receipt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val receiptNo: String,
    val createdAt: Long,
    val issuer: String,
    val customer: String,
    val phone: String,
    val service: String,
    val total: Long,
    val paid: Long,
    val method: String,
    val reference: String,
    val note: String,
    val jpegPath: String
) {
    val balance: Long get() = (total - paid).coerceAtLeast(0L)
}
