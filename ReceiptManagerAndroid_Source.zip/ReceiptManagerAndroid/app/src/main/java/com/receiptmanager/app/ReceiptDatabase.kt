package com.receiptmanager.app

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Receipt::class], version = 1, exportSchema = false)
abstract class ReceiptDatabase : RoomDatabase() {
    abstract fun receiptDao(): ReceiptDao
    companion object {
        @Volatile private var INSTANCE: ReceiptDatabase? = null
        fun get(context: Context): ReceiptDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                ReceiptDatabase::class.java,
                "receipt_manager.db"
            ).build().also { INSTANCE = it }
        }
    }
}
