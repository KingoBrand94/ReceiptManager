package com.receiptmanager.app

import android.content.Context
import android.graphics.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReceiptImage {
    private const val W = 1080
    private const val H = 1600
    private val dark = Color.rgb(24, 65, 52)
    private val green = Color.rgb(54, 168, 90)
    private val pale = Color.rgb(233, 244, 237)
    private val ink = Color.rgb(39, 70, 59)

    fun create(context: Context, r: Receipt): File {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.rgb(233, 241, 235))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        c.drawRoundRect(50f, 45f, 1030f, 1555f, 42f, 42f, p)

        p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = green
        c.drawCircle(540f, 125f, 25f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 7f
        c.drawLine(527f, 125f, 537f, 135f, p); c.drawLine(537f, 135f, 555f, 112f, p)
        p.style = Paint.Style.FILL
        centered(c, "PAYMENT RECEIVED", 540f, 220f, 53f, dark, true)
        centered(c, "MALIPO YAMEPOKELEWA", 540f, 270f, 30f, ink, false)
        line(c, 120f, 350f, 960f, 350f)

        centered(c, "AMOUNT PAID", 540f, 470f, 30f, ink, false)
        centered(c, "TZS ${money(r.paid)}", 540f, 555f, 64f, dark, true)
        p.color = pale; c.drawRoundRect(340f, 585f, 740f, 655f, 35f, 35f, p)
        centered(c, if (r.balance == 0L) "PAYMENT SUCCESSFUL" else "PARTIAL PAYMENT", 540f, 630f, 25f, green, false)

        line(c, 120f, 720f, 960f, 720f)
        val rows = mutableListOf(
            "Client" to r.customer,
            "Service" to r.service,
            "Balance" to "TZS ${money(r.balance)}",
            "Date & Time" to SimpleDateFormat("dd MMM yyyy | hh:mm a", Locale.ENGLISH).format(Date(r.createdAt)),
            "Reference No." to r.receiptNo,
            "Payment Method" to r.method
        )
        if (r.reference.isNotBlank()) rows.add("Transaction Ref." to r.reference)
        var y = 790f
        rows.forEach { (label, value) ->
            left(c, label, 120f, y, 27f, ink, false)
            right(c, fit(value, 31), 960f, y, 25f, dark, true)
            y += 76f
        }
        p.color = pale; c.drawRoundRect(120f, 1260f, 960f, 1420f, 28f, 28f, p)
        centered(c, "THANK YOU FOR YOUR PAYMENT!", 540f, 1325f, 30f, dark, true)
        centered(c, "We appreciate your trust in our services.", 540f, 1370f, 22f, ink, false)
        centered(c, r.issuer.ifBlank { "PAYMENT RECEIPT" }, 540f, 1490f, 38f, dark, true)

        val dir = File(context.filesDir, "receipts").apply { mkdirs() }
        val file = File(dir, "${r.receiptNo.replace(Regex("[^A-Za-z0-9_-]"), "_")}.jpg")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        bmp.recycle()
        return file
    }

    private fun money(n: Long) = "%,d".format(Locale.US, n)
    private fun fit(s: String, max: Int) = if (s.length > max) s.take(max - 1) + "…" else s
    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(109,130,121); strokeWidth = 2f }
        c.drawLine(x1,y1,x2,y2,p)
    }
    private fun centered(c: Canvas, text: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; textSize = size; textAlign = Paint.Align.CENTER
            typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        }
        c.drawText(text, x, y, p)
    }
    private fun left(c: Canvas, text: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color=color; textSize=size; textAlign=Paint.Align.LEFT; typeface=if(bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }
        c.drawText(text,x,y,p)
    }
    private fun right(c: Canvas, text: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color=color; textSize=size; textAlign=Paint.Align.RIGHT; typeface=if(bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }
        c.drawText(text,x,y,p)
    }
}
