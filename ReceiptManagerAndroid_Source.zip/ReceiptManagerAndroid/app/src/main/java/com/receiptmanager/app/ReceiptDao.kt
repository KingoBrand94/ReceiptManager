package com.receiptmanager.app

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ReceiptDao {
    @Insert suspend fun insert(receipt: Receipt): Long
    @Query("SELECT * FROM receipts ORDER BY createdAt DESC") suspend fun all(): List<Receipt>
    @Query("SELECT * FROM receipts WHERE id = :id LIMIT 1") suspend fun byId(id: Long): Receipt?
    @Query("SELECT COUNT(*) FROM receipts") suspend fun count(): Int
    @Query("SELECT COALESCE(SUM(paid),0) FROM receipts") suspend fun totalPaid(): Long
    @Query("SELECT COALESCE(SUM(CASE WHEN total > paid THEN total-paid ELSE 0 END),0) FROM receipts") suspend fun totalBalance(): Long
    @Query("SELECT * FROM receipts WHERE customer LIKE '%' || :query || '%' OR receiptNo LIKE '%' || :query || '%' OR service LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    suspend fun search(query: String): List<Receipt>
}
