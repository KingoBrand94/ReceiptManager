package com.receiptmanager.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF176B57)
private val Pale = Color(0xFFE8F5EF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = ReceiptDatabase.get(this).receiptDao()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFF36A85A))) {
                ReceiptApp(dao)
            }
        }
    }
}

@Composable
private fun ReceiptApp(dao: ReceiptDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("new") }
    var issuer by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Cash") }
    var reference by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<Receipt>()) }
    var selected by remember { mutableStateOf<Receipt?>(null) }
    var count by remember { mutableIntStateOf(0) }
    var totalPaid by remember { mutableLongStateOf(0L) }
    var balance by remember { mutableLongStateOf(0L) }

    fun refresh() { scope.launch { history = dao.all(); count = dao.count(); totalPaid = dao.totalPaid(); balance = dao.totalBalance() } }
    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)) {
                Text("Receipt Manager", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Mfumo wa risiti na kumbukumbu za malipo", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = page == "new", onClick = { page = "new" }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Risiti mpya") })
                NavigationBarItem(selected = page == "history", onClick = { page = "history"; refresh() }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Historia") })
                NavigationBarItem(selected = page == "settings", onClick = { page = "settings" }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Taarifa") })
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (page == "new") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard("Risiti", count.toString(), Modifier.weight(1f))
                    SummaryCard("Imelipwa", "TZS ${money(totalPaid)}", Modifier.weight(1f))
                }
                SummaryCard("Salio lote", "TZS ${money(balance)}", Modifier.fillMaxWidth())
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Taarifa za risiti", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Field("Jina la biashara / mtoa risiti", issuer, { issuer = it }, false)
                        Field("Jina la mteja *", customer, { customer = it })
                        Field("WhatsApp ya mteja (255...)", phone, { phone = it })
                        Field("Huduma / bidhaa *", service, { service = it })
                        Field("Jumla ya bili (TZS) *", total, { total = it }, number = true)
                        Field("Kiasi kilicholipwa (TZS) *", paid, { paid = it }, number = true)
                        Text("Njia ya malipo", fontWeight = FontWeight.SemiBold)
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(method) }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                listOf("Cash","M-Pesa","Tigo Pesa","Airtel Money","HaloPesa","Benki","Kadi","Nyingine").forEach {
                                    DropdownMenuItem(text = { Text(it) }, onClick = { method = it; expanded = false })
                                }
                            }
                        }
                        Field("Namba ya muamala (hiari)", reference, { reference = it }, false)
                        Field("Maelezo ya ziada (hiari)", note, { note = it }, false)
                        Button(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                val t = total.toLongOrNull(); val p = paid.toLongOrNull()
                                if (customer.isBlank() || service.isBlank() || t == null || p == null || t < 0 || p < 0 || p > t) {
                                    Toast.makeText(context, "Jaza jina, huduma na kiasi sahihi. Malipo yasizidi bili.", Toast.LENGTH_LONG).show()
                                } else {
                                    scope.launch {
                                        val stamp = System.currentTimeMillis()
                                        val prefix = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(stamp))
                                        val no = "RC-$prefix"
                                        val draft = Receipt(0, no, stamp, issuer.trim(), customer.trim(), phone.trim(), service.trim(), t, p, method, reference.trim(), note.trim(), "")
                                        val image = ReceiptImage.create(context, draft)
                                        val id = dao.insert(draft.copy(jpegPath = image.absolutePath))
                                        selected = draft.copy(id = id, jpegPath = image.absolutePath)
                                        refresh()
                                        Toast.makeText(context, "Risiti imetengenezwa na kuhifadhiwa ndani ya App.", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        ) { Text("Tengeneza na hifadhi risiti") }
                    }
                }
                selected?.let { ReceiptActions(it) }
            } else if (page == "history") {
                OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Tafuta risiti, mteja au huduma") }, singleLine = true)
                LaunchedEffect(search) { history = dao.search(search) }
                if (history.isEmpty()) Text("Bado hakuna risiti zilizohifadhiwa.", color = Color.Gray)
                history.forEach { r ->
                    Card(Modifier.fillMaxWidth().clickable { selected = r }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(r.receiptNo, fontWeight = FontWeight.Bold)
                            Text(r.customer)
                            Text(r.service, color = Color.Gray)
                            Text("Imelipwa: TZS ${money(r.paid)}  •  Salio: TZS ${money(r.balance)}")
                            Text("Gusa kuona vitufe vya kushiriki", color = Green, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
                selected?.let { ReceiptActions(it) }
            } else {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Taarifa", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Jina la mtoa risiti linaweza kuwekwa kwenye kila risiti. App haina logo au jina la biashara lililofungwa.")
                        Text("JPEG na database huhifadhiwa ndani ya App. Ukifuta App au data zake, taarifa zinaweza kupotea; toleo hili bado halina backup ya kurejesha.")
                        Text("Risiti hii ni ya ndani ya biashara, si risiti rasmi ya kodi/EFD.")
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp)) { Text(label, color = Color.Gray); Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) } }
}

@Composable
private fun Field(label: String, value: String, onValue: (String) -> Unit, required: Boolean = true, number: Boolean = false) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        label = { Text(label) }, singleLine = true,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
            keyboardType = if (number) androidx.compose.ui.text.input.KeyboardType.Number else androidx.compose.ui.text.input.KeyboardType.Text
        )
    )
}

@Composable
private fun ReceiptActions(r: Receipt) {
    val context = LocalContext.current
    val file = File(r.jpegPath)
    Card(colors = CardDefaults.cardColors(containerColor = Pale)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Risiti: ${r.receiptNo}", fontWeight = FontWeight.Bold)
            Text("Mteja: ${r.customer}")
            Text("Kiasi: TZS ${money(r.paid)}  •  Salio: TZS ${money(r.balance)}")
            Button(onClick = {
                if (!file.exists()) {
                    Toast.makeText(context, "Picha ya risiti haijapatikana.", Toast.LENGTH_LONG).show()
                } else {
                    val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_TEXT, "Risiti ${r.receiptNo} - ${r.customer}. Kiasi kilicholipwa: TZS ${money(r.paid)}. Salio: TZS ${money(r.balance)}.")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Shiriki risiti"))
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Shiriki JPEG / WhatsApp") }
        }
    }
}

private fun money(n: Long) = "%,d".format(Locale.US, n)
