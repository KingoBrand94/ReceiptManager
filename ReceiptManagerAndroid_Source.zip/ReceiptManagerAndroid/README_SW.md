# Receipt Manager — Android source

App ya Android ya offline kwa kutengeneza na kuhifadhi risiti, kutengeneza JPEG ndani ya app na kushiriki kupitia Android share sheet (chagua WhatsApp).

## Muhimu
- Haina logo wala jina la brand maalumu.
- Database ya Room na JPEG huhifadhiwa kwenye private app storage.
- Toleo hili linahitaji kujengwa kwa Android SDK; halijawa APK iliyojengwa.
- Kwa matumizi ya msingi hakuna internet permission.
- Ukifuta app/data, historia inaweza kufutika. Tengeneza backup kabla ya matumizi muhimu.
- Hii ni risiti ya ndani ya biashara; si mbadala wa TRA/EFD pale inapohitajika.

## Kujenga APK
Mradi huu unahitaji Android SDK, JDK 17 na Gradle kupitia Android Studio au Android IDE inayounga mkono Android Gradle Plugin 8.7.3.

1. Extract ZIP.
2. Fungua folder `ReceiptManagerAndroid` katika Android Studio/Android IDE.
3. Ruhusu Gradle Sync kupakua dependencies.
4. Build > Build APK(s).
5. APK ya debug itakuwa `app/build/outputs/apk/debug/app-debug.apk`.

## Kutumia kwa simu pekee
Unaweza kujaribu AndroidIDE au AIDE ikiwa toleo lake linaunga mkono Kotlin, Jetpack Compose na Android Gradle Plugin inayohitajika. Ulinganifu hutegemea toleo la IDE; kama build itashindwa, tumia build environment inayounga mkono AGP 8.7.3/JDK 17 au GitHub Actions.

## Vipengele
- Dashboard ya jumla ya risiti, malipo na salio
- Form ya risiti
- Database ya Room offline
- JPEG ya 1080 x 1600
- Historia na utafutaji
- Kushiriki picha kupitia Android share sheet
